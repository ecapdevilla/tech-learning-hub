function rollOnce() {
  const value = DiceModel.rollDice();
  DiceView.showDice(value);
  DiceView.showHistory(DiceModel.rolls);
}
document.getElementById("rollBtn").addEventListener("click", rollOnce);
document.getElementById("roll10Btn").addEventListener("click", () => {
  for (let i = 0; i < 10; i++) {
    rollOnce();
  }
});
document.getElementById("resetBtn").addEventListener("click", () => {
  DiceModel.reset();
  DiceView.showDice("🎲");
  DiceView.showHistory([]);
});
